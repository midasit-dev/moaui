import * as React from 'react';
import PropTypes from 'prop-types';

import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box'
import InputAdornment from '@mui/material/InputAdornment';
import { MathJax, MathJaxContext } from "better-react-mathjax";

//Base Text Style
const Div = styled('div')(({ theme }) => ({
  ...theme.typography.body2,
  backgroundColor: theme.palette.background.paper,
  marginTop: "3px",
  padding: theme.spacing(0),
  fontSize:"12px"
}));

//Text Field Style
function StyledTextField(props) {
  const {defaultValue, units, value, onChange, disabled, width, type} = props;

  return(
    <TextField
      disabled={disabled}
      hiddenLabel
      defaultValue={defaultValue}
      variant="standard"
      size="small"
      value={value}
      onChange={e=>onChange(e.target.value)}
      type={type}
      InputProps={{
        sx: {
          fontSize: "12px",
          width:{width},
          "& input":{
            textAlign:"right",
          },
/*           '& input[type=number]::-webkit-inner-spin-button': {
            //'-webkit-appearance': 'none',
            opacity: 1,
            margin: 0,
            marginLeft:"5px",
          }, */
        },
        endAdornment: 
          <InputAdornment position="end">
            <Div>{units}</Div>
          </InputAdornment>,
      }}
    />
  )
}

StyledTextField.propTypes = {
  onChange: PropTypes.func.isRequired,
};

function BasicInputField(title, symbol, units, values, SetValue, type="number") {
  return (
    <Box sx={{margin:1, marginLeft:3, marginTop:0.5, marginBottom:0.5}}>
      <Stack direction="row" spacing={2} justifyContent="space-between">
        <Div>{title}</Div>
        <Stack direction="row" alignItems="center" spacing={2}>
          <MathJaxContext><MathJax className = "mathStyle">{symbol}</MathJax></MathJaxContext>
          <StyledTextField value={values} type={type} onChange={SetValue} width={70}/>
          <Box sx={{width:"30px"}}><MathJaxContext><MathJax className = "mathStyle">{units}</MathJax></MathJaxContext></Box>
        </Stack>
      </Stack>
    </Box>
  );
}

function BasicInputFieldHidden(title, symbol, units, values, SetValue) {
  return (
    <Box sx={{margin:1, marginLeft:3, marginTop:0.5, marginBottom:0.5}}>
      <Stack direction="row" spacing={2} justifyContent="space-between">
        <Div>{title}</Div>
        <Stack direction="row" alignItems="center" spacing={2}>
          <MathJaxContext><MathJax className = "mathStyle">{symbol}</MathJax></MathJaxContext>
          <StyledTextField value={values} onChange={SetValue} disabled={true} width={70}/>
          <Box sx={{width:"30px"}}><MathJaxContext><MathJax className = "mathStyle">{units}</MathJax></MathJaxContext></Box>
        </Stack>
      </Stack>
    </Box>
  );
}

function SubInputField(title=NaN, values, SetValue, Display) {
  return (
    <Box sx={{margin:1.0, marginLeft:6}}>
      <Stack direction="row" pacing={2} justifyContent="space-between">
          <Div>{title}</Div>
        <StyledTextField units="" type="number" value={values} onChange={SetValue} disabled={Display} width={70}/>
      </Stack>
    </Box>
  );
}

function SubInputFieldWide(title=NaN, values, SetValue) {
  return (
    <Box sx={{margin:1.0, marginLeft:3}}>
      <Stack direction="row" apacing={2} justifyContent="space-between">
          <Div>{title}</Div>
        <StyledTextField value={values} onChange={SetValue} disabled={false} width={160}/>
      </Stack>
    </Box>
  );
}

export{BasicInputField, BasicInputFieldHidden, SubInputField, SubInputFieldWide}