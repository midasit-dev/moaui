import * as React from 'react';
import Box from '@mui/material/Box';
import NativeSelect from '@mui/material/NativeSelect';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import FormControl from '@mui/material/FormControl';

//Base Text Style
const Div = styled('div')(({ theme }) => ({
  ...theme.typography.body2,
  backgroundColor: theme.palette.background.paper,
  marginTop: "3px",
  padding: theme.spacing(0),
  fontSize:"12px"
}));

export default function SelectVariants(title, preSetList, preListNb, setPreListNb) {
  return (
    <div>
      <Box sx={{margin:1.0, marginLeft:3}}>
      <Stack direction="row" component="form" spacing={2} justifyContent="space-between">
      <Div>{title}</Div>
        <FormControl sx={{minWidth: 140}} size="small">
          <NativeSelect
            sx={{textAlign:'center'}}
            value={preListNb}
            onChange={(e)=>setPreListNb(e.target.value)}
            size="small"
            inputProps={{
              name: 'age',
              id: 'uncontrolled-native',
              sx: {
                fontSize: "12px",
                "& input":{
                  textAlign:"center",
                }
              }
            }}
          >
            <option value={10}>{preSetList[10]}</option>
            <option value={20}>{preSetList[20]}</option>
            <option value={30}>{preSetList[30]}</option>
            <option value={40}>{preSetList[40]}</option>
            <option value={50}>{preSetList[50]}</option>
          </NativeSelect>
          </FormControl>
      </Stack>
      </Box>
    </div>
  );
}
