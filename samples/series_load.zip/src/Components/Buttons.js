import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';

const MainColorButton = styled(Button)(({ theme }) => ({
  color: theme.palette.getContrastText("#0288D1"),
  fontSize : '12px',
  backgroundColor: "#0288D1",
  '&:hover': {
    backgroundColor: "#4DABDF",
  },
}));

const SubColorButton = styled(Button)(({ theme }) => ({
  color: theme.palette.getContrastText("#F3BB2C"),
  fontSize : '12px',
  backgroundColor: "#F3BB2C",
  '&:hover': {
    backgroundColor: "#F7CF6B",
  },
}));

export function NormalButton(types, texts, clickevent) {
  return (
    <Stack spacing={2} direction="row" alignItems="center">
      <MainColorButton size="small" variant={types} onClick = {clickevent} sx={{margin:0.5, width:90,height:40}}>{texts}</MainColorButton>
    </Stack>
  );
};

export function WideButton(types, texts, clickevent) {
  return (
    <Stack spacing={2} direction="row">
      <MainColorButton size="small" variant={types} onClick = {clickevent} sx={{width:160,height:40}}>{texts}</MainColorButton>
    </Stack>
  );
};

export function WideButtonSubColor(types, texts, clickevent) {
  return (
    <Stack spacing={2} direction="row">
      <SubColorButton size="small" variant={types} onClick = {clickevent} sx={{width:160,height:40}}>{texts}</SubColorButton>
    </Stack>
  );
};

export function ElemButton(types, texts, clickevent) {
  return (
    <Stack spacing={2} direction="row">
      <MainColorButton size="small" variant={types} onClick = {clickevent} sx={{width:100,height:40}}>{texts}</MainColorButton>
    </Stack>
  );
};