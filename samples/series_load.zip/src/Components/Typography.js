import * as React from 'react';
import Box from '@mui/material/Box'
import { Typography } from '@mui/material';

export default function StyledTypo(title) {
  return (
    <Box sx={{margin:1, marginTop:0.5, marginBottom:0.5}}>
      <Typography variant="subtitle2" sx={{fontSize:"13px", fontWeight:"bold"}}>{title}</Typography>
    </Box>
  );
}