import * as React from 'react';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { Typography } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';

const outerTheme = createTheme({
  palette: {
    primary: {
      main: "#1F3B62",
    },
  },
});

export default function CheckboxOption(Title, checked, setChecked) {
  return (
    <ThemeProvider theme={outerTheme}>
      <FormControlLabel
        label={
          <Typography sx={{ fontSize: "12px" }}>
            {Title}
          </Typography>
        }
        sx={{ marginLeft:1}}
        control={
        <Checkbox
          checked={checked}
          onChange={(e) => setChecked(e.target.checked)}
          inputProps={{ 'aria-label': 'controlled' }}
          sx={{ '& .MuiSvgIcon-root': { fontSize: 14 } }}
          />
        }
      />
      </ThemeProvider>
  );
}