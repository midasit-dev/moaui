# Easy Load Combinations
- Create Load Combinations with convertible and comfortable Plug-in.
## Details
### version 1.0.0
- Import and update load cases automatically, just the same as your MIDAS modeling file.
- Just **select** and create a **new load combination** including **factors**.
- Send your combined load cases into your model by clicking one time.
