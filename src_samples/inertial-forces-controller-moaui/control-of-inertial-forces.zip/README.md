<!-- markdownlint-disable-next-line -->
<br />
<p align="center">
  <a href="https://midasit.com/" rel="noopener" target="_blank"><img width="150" src="https://raw.githubusercontent.com/midasit-dev/moaui/main/logo_circle.svg" alt="moaui logo"></a>
</p>

<h1 align="center">cra-template-moaui (for code)</h1>

<p align="center">To upload the created code to a version control repository like GitHub and provide explanations, <br />
you can modify this README.md file.</p>