// global.d.ts
import React from 'react';

declare global {
  const pyscript: any;
}